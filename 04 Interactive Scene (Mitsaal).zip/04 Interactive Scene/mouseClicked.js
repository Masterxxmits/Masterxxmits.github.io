// Change weather
function mouseClicked() {
  fill(0, 0, 0);
  rect(windowWidth * .10, windowHeight, windowHeight * .4, windowWidth * .4);
}
